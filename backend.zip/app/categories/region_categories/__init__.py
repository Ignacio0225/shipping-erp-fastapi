# app/region_categories/__init__.py
from .region_categories_models import RegionCategory
