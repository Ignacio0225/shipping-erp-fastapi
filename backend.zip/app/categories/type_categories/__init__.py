# app/type_categories/__init__.py
from .type_categories_models import TypeCategory
