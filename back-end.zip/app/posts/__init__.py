# app/users/__init__.py
from .shipments_models import Shipment
