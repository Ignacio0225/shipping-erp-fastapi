# app/users/__init__.py
from .users_models import User
